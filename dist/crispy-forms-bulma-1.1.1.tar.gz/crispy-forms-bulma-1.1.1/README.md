crispy-forms-bulma
==

### About
This is a `Django`_ application to add `django-crispy-forms` layout objects for [Bulma](https://bulma.io/).

### Installation
Install package from pip or clone it from github  
`pip install crispy-forms-bulma`

Add package settings to your project settings file  
`from crispy_forms_bulma.settings import *`

Enjoy